# frozen_string_literal: true

module Cartao
  def  bandeira(bandeira_cartao, numero_cartao, valor_pagar )
    puts "Você está pagando com: #{bandeira_cartao}, O número do cartão: #{numero_cartao} no valor de: #{valor_pagar}"
  end
end
