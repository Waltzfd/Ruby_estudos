# frozen_string_literal: true

class Passaro
  attr_accessor :passaros

  def initialize (passaros)
    @passaros = passaros
  end

  def repetir_frase(texto = "Bom dia,Bom dia, Bom dia")
    puts texto

  end

  papagaio = Passaro.new(["Papagaio, Cuco, Arara"])
  papagaio.repetir_frase
  papagaio.repetir_frase("bestão, bestão, bestão")
  puts papagaio.passaros
  papagaio2 = Passaro.new(["Andorinha, Pitohui, Pavão"])
  papagaio2.repetir_frase
  papagaio2.repetir_frase("Estou aqui,Estou aqui!")

  puts papagaio2.passaros
end

