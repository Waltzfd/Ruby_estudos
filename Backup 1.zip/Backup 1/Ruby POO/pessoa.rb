# frozen_string_literal: true

class Pessoa

  def gritar (texto)
    puts "Gritando....#{texto}"
  end

  def falar (talk)
    puts talk
  end

  obj1 = Pessoa.new
  obj1.gritar ("GRRRRRR")
  obj1.falar("Oi")


end
