# frozen_string_literal: true

class Animal
    attr_accessor :racas

    def initialize(racas)
      @racas = racas
    end


def latir (texto = "GRRRR")
  puts texto
end
    end
    # Criando uma nova instância de Animal com uma matriz de raças
    cachorro = Animal.new(["Rottweiler", "Shi Tzu"])

    # Não é necessário criar uma nova instância de Animal sem argumentos, já que não há nenhum método que não exija argumentos
    # acao1 = Animal.new

    # Acessando o método latir da instância cachorro com um texto personalizado
    cachorro.latir("AUUUUUUUUUUU")

    # Acessando a variável de instância racas da instância cachorro e imprimindo-a
    puts cachorro.racas

    # Chamando o método latir da instância acao1, mas como ele não recebe nenhum argumento, imprimirá o texto padrão
  acao1 = Animal.new("poodle")
  puts acao1.racas
  acao1.latir


