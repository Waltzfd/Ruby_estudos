# frozen_string_literal: true

class Funcionario
  attr_accessor :nome, :cpf ,:salario

end

class Gerente<Funcionario
  attr_accessor :senha , :tempo_Empresa
end

f = Funcionario.new
f.nome = (["Cláudio"])
f.cpf = 156874
f.salario = 64.5

puts f.nome
puts f.cpf
puts f.salario

g = Gerente.new
g.nome = (["Alessandro"])
g.cpf = 56842
g.salario = 68.9
g.senha = 6687
g.tempo_Empresa = 6

puts g.nome
puts g.cpf
puts g.salario
puts g.senha
puts g.tempo_Empresa