# frozen_string_literal: true

class Calculadora
  def somar (n1,n2)
    n1+n2
  end
end

class CalculadoraFashion < Calculadora
  #Overriding
  def somar(n1,n2)
    "A Soma é #{n1+n2}"
  end
end

c = Calculadora.new
puts c.somar(2,4)

cf = CalculadoraFashion.new
puts cf.somar(2,3)


